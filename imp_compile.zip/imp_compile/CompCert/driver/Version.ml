let version = "3.8"
let buildnr = ""
let tag = ""
let branch = ""
