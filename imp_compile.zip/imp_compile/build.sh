ocamlbuild -pkgs unix,str,menhirLib -r test.native
